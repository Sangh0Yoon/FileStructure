#include "CourseRegistration.h"
#include "Student.h"
#include <string>
#include <iostream>
using namespace std;
int main() {
	CourseRegistration Math;
	Math.set_course("math");
	Math.set_creditHours(3);
	Math.set_grade(90.0);

	Student st1;
	st1.modify_name("YoonSangho");
	st1.modify_address("Busan");
	st1.modify_date("2022��03��27��");
	st1.modify_creditHours(16);
	st1.modify_id(1);
	Math.add(st1);

	Student st2;
	st2.modify_name("YooSijin");
	st2.modify_address("UAE");
	st2.modify_date("2022��03��11��");
	st2.modify_creditHours(19);
	st2.modify_id(2);
	Math.add(st2);
	

	Student st3;
	st3.modify_name("Tokki");
	st3.modify_address("Moon");
	st3.modify_date("2022��02��27��");
	st3.modify_creditHours(22);
	st3.modify_id(3);
	Math.add(st3);

	Student st4;
	st4.modify_name("Golila");
	st4.modify_address("Forest");
	st4.modify_date("2022��01��27��");
	st4.modify_creditHours(16);
	st4.modify_id(4);
	Math.add(st4);

	Student st5;
	st5.modify_name("GOOGLE");
	st5.modify_address("USA");
	st5.modify_date("2021��08��11��");
	st5.modify_creditHours(23);
	st5.modify_id(5);
	Math.add(st5);

	Math.print_all();

	system("pause");
}
