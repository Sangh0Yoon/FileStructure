#ifndef COURSEREGISTRATION
#define COURSEREGISTRATION
#include "Student.h"
#include <iostream>
#include <vector>
using namespace std;
class CourseRegistration {
public:
	int st_id; int _creditHours; float _grade;
	char course[16];
	CourseRegistration() {
		st_id = 0; _creditHours = 0; _grade = 0;  course[0] = 0;
	}
	void set_course(char* str) {
		strcpy(course, str);
	}
	void set_creditHours(int creditHours) {
		_creditHours = creditHours;
	}
	void set_grade(float grade) {
		_grade = grade;
	}
	void add(Student& st) {
		st_id = st.Identifier;
		l.push_back(st);
	}
	void print_all() {
		for (auto& st : l) {
			cout << "id : " << st.Identifier << endl;
			cout << "name : " << st.Name << endl;
			cout << "address : " << st.Address << endl;
			cout << "date of first enrollment : " << \
				st.DateOfFirstEnrollment << endl;
			cout << "number of credit hours completed : " << \
				st.NumberOfCreditHourse << endl;
			cout << "--------------------------------" << endl;
		}
	}
private:
	vector<Student> l;
};

#endif
