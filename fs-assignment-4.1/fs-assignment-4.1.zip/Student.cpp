#include <iostream>
#include <string>
#include <algorithm>
#include "Student.h"
using namespace std;

Student::Student(){
	Identifier = 0; Name[0] = 0; Address[0] = 0;
	DateOfFirstEnrollment[0] = 0; NumberOfCreditHourse = 0;
}
void Student::modify_id(int id) {
	Identifier = id;
}

void Student::modify_creditHours(int creditHours) {
	NumberOfCreditHourse = creditHours;
}
void Student::modify_date(char* date) {
	strcpy(DateOfFirstEnrollment, date);
}
void Student::modify_name(char* name) {
	strcpy(Name, name);
}
void Student::modify_address(char* address) {
	strcpy(Address, address);
}
void Student::add_creditHours(int add) {
	NumberOfCreditHourse += add;
}

Student& Student::operator=(Student& st) {
	modify_id(st.Identifier); 
	modify_creditHours(st.NumberOfCreditHourse);
	modify_address(st.Address);
	modify_date(st.DateOfFirstEnrollment);
	modify_name(st.Name);
	return *this;
}