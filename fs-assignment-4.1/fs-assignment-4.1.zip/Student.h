#ifndef STUDENT
#define STUDENT
using namespace std;
class Student {
public:
	int Identifier; char Name[11]; char Address[16];
	char DateOfFirstEnrollment[16]; int NumberOfCreditHourse;
	Student();
	void modify_id(int id);
	void modify_creditHours(int creditHours);
	void modify_date(char* date);
	void modify_name(char* name);
	void modify_address(char* address);
	void add_creditHours(int add);
	Student& operator=(Student& st);
};
#endif